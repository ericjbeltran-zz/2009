<?php
require_once(TEMPLATEPATH . '/controlpanel.php'); 
if ( function_exists('register_sidebars') )
    register_sidebars(2);
	?>