var $jx = jQuery.noConflict(); 
$jx(document).ready(function() {
	$jx('#tabzine> ul').tabs({ fx: { height: 'toggle', opacity: 'toggle' } });

});
