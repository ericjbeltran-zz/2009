<div class="clear"></div>
</div>	
<div id="footbar">
 
<div class="about"> 
<h2 class="au">Recent Comments</h2>
<?php 
	$img = get_option('tri_img'); 
	$about = get_option('tri_about'); 
	?>			
<p class="text">
<img src="<?php echo ($img); ?>" class="avatar" alt="" />
<?php echo ($about); ?> 
</p>
</div>
 
 
<div class="barone">
<h2 class="rc">Recent Comments</h2>
<div class="ranlist">

<?php $my_query = new WP_Query('showposts=5&orderby=rand'); ?>
<?php while ($my_query->have_posts()) : $my_query->the_post();?>

<div class="rblock">
<?php $screen = get_post_meta($post->ID,'screen', true); ?>
<img src="<?php echo ($screen); ?>" width="60" height="40" alt=""  />

<h3><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>

<div class="fmeta"> On <?php the_time('M-j-Y'); ?> </div>
<div class="fmeta"> Reported by <?php the_author(); ?></div>
</div>
<?php endwhile; ?>
</div>
</div>

 
 
<div class="barone" >
<h2 class="rp">Recent Posts</h2>
		   <?php
    global $wpdb;

    $sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID,
    comment_post_ID, comment_author, comment_date_gmt, comment_approved,
    comment_type,comment_author_url,
    SUBSTRING(comment_content,1,30) AS com_excerpt
    FROM $wpdb->comments
    LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID =
    $wpdb->posts.ID)
    WHERE comment_approved = '1' AND comment_type = '' AND
    post_password = ''
    ORDER BY comment_date_gmt DESC
    LIMIT 5";
    $comments = $wpdb->get_results($sql);

    $output = $pre_HTML;
    $output .= "\n<ul>";
    foreach ($comments as $comment) {

    $output .= "\n<li><b>".strip_tags($comment->comment_author)
    ."</b>:&nbsp;<br/>" . "<a href=\"" . get_permalink($comment->ID) .
    "#comment-" . $comment->comment_ID . "\" title=\"on " .
    $comment->post_title . "\">" . strip_tags($comment->com_excerpt)
    ."</a></li>";

    }
    $output .= "\n</ul>";
    $output .= $post_HTML;

    echo $output;?>
</div>
</div>