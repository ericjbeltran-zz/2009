
<div id="rightcol">

<?php include (TEMPLATEPATH . '/fvideo.php'); ?>
<?php include (TEMPLATEPATH . '/sponsors.php'); ?>
<?php include (TEMPLATEPATH . '/searchform.php'); ?>
<?php include (TEMPLATEPATH . '/tab.php'); ?>
<div id="sidebar">
<?php include (TEMPLATEPATH . '/sidebar2.php'); ?>
<?php include (TEMPLATEPATH . '/sidebar1.php'); ?>		
</div>
</div>

