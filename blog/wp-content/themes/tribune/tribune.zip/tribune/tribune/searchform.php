<div id="search">
			<form method="get" id="searchform" action="<?php bloginfo('home'); ?>" >
					<input id="s" type="text" name="s" value="" onblur="if(this.value == '') {this.value = 'Site Search ';}" onfocus="if(this.value == 'Site Search') {this.value = '';}"  />
					

					<input id="searchsubmit" type="submit" value="" />
			
				</form>

</div>