



<div class="ad1"> 

<?php $ad1 = get_option('tri_ad1'); echo stripslashes($ad1); ?>

</div>