
<div id="fideohead"></div>

<div id="fvideo">
<?php $vid = get_option('tri_video'); echo stripslashes($vid); ?>
</div>
 <div class="clear"></div>