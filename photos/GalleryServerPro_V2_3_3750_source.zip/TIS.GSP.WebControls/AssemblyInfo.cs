using System.Reflection;
using System.Runtime.CompilerServices;
using System.Web.UI;

[assembly: TagPrefix("GalleryServerPro.WebControls", "tis")]

[assembly: AssemblyTitle("GalleryServerPro.Controls")]
[assembly: AssemblyDescription("Tech Info Systems Controls and Components")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Tech Info Systems")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("Copyright � Tech Info Systems, LLC 2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("2.3.*")]

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]

[assembly: System.Runtime.InteropServices.ComVisible(false)]
[assembly: System.CLSCompliant(true)]
