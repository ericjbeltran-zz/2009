﻿using System;

namespace GalleryServerPro.Web.Controls
{
	public partial class popupinfo : GalleryUserControl
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}
	}
}