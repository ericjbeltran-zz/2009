﻿using System;
using GalleryServerPro.Web.Controls;

namespace GalleryServerPro.Web.gs.controls
{
	public partial class myaccount : GalleryUserControl
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}
	}
}