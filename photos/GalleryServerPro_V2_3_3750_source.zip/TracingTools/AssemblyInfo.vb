Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("TechInfoSystems.TracingTools")> 
<Assembly: AssemblyDescription("Provides generic tracing functionality for applications.")> 
<Assembly: AssemblyCompany("Tech Info Systems, LLC")> 
<Assembly: AssemblyProduct("")> 
<Assembly: AssemblyCopyright("Copyright � Tech Info Systems, LLC 2010")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: CLSCompliant(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("CBFB344B-D6F0-426A-B0D0-72C4F1557C6C")> 

<Assembly: AssemblyVersion("1.0.2.4")> 
